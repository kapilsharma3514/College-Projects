<?php
  error_reporting(E_ALL^E_DEPRECATED);
  $link = mysql_connect("localhost","root","");
  mysql_select_db("eduspace",$link);
?>



