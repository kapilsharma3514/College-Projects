<?php
	session_start();
	include('config.php');
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/search_config.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link type="text/javascript" href="script/home.js">
<link rel="icon" href="images/home_button.png">
<script language="javascript">
function log_me_out() {
		window.location.href="log_me_out.php";
	}
</script>
<script src="script/jquery-1.11.3.min.js"></script>
<script>
$(document).ready(function(e) {
     $(window).scroll(function() { 
        var scroll = $(window).scrollTop();
 
        if (scroll > 4) {$("#log").attr('src','images/icon.png');
            $(".header").addClass('smaller');
			$(".smaller").removeClass('header');
			
        } else {$("#log").attr('src','images/logo2.png');
            $(".smaller").addClass("header");
			$(".header").removeClass("smaller");
			
        }
    });
});


</script>
<script>

	function log_me_out() {
		window.location.href="log_me_out.php";
	}
	
	function playvalidate() {
		var e = document.getElementById("playselect");
		var strUser = e.options[e.selectedIndex].value;
		if (strUser!="name" && strUser!="localty" && strUser!="pincode")
		{
			alert('Choose A Filter');
			return false;
		}
		return true;
	}
</script>

<title>EduSpace</title>

<meta name="viewport" content="width=device-width, initial-scale=1">

</head>

<body style="margin: 0px;">

<div class="pre_header">
	<div class="pre_header_option">
    	Register School
	</div>
    <div class="pre_header_option">
		Contact Us
    </div>
<?php
	if (isset($_SESSION["name"]))
	{
?>
	<a href="edit_user.php?x=<?php echo $_SESSION["id"]; ?>" style="text-decoration:none;">
	<div class="pre_header_option">
		Edit Account
    </div>
	</a>
	<a href="delete_user.php?x=<?php echo $_SESSION["id"]; ?>" style="text-decoration:none;">
	<div class="pre_header_option">
		Delete Account
    </div>
	</a>
	<a href="fav.php?x=<?php echo $_SESSION["id"]; ?>" style="text-decoration:none;">
	<div class="pre_header_option">
		Favourites
    </div>
	</a>
	<a href="edit_user.php?x=<?php echo $_SESSION["id"]; ?>" style="text-decoration:none;">
	<div class="pre_header_option">
		Test Results
    </div>
	</a>
<?php
	}
?>
</div>

<div class="header navbar-fixed-top" style="margin-top:2.5%;">
<div class="header_left" id="LOGO">
<img src="images/logo2.png" width="100%" height="100%" id="log" class="l"></div>
<?php
	if (!isset($_SESSION["name"]))
	{
?>
<a href="login.php" style="text-decoration:none;">
<div class="header_right" id="Login" > 
Login
<div class="line_bottom" style="display:none;">
</div>
</div>
<?php
	}
	else
	{
?>
<a href="login.php" style="text-decoration:none;">
<div class="header_right" id="Login" onclick="log_me_out()"> 
Hi <span style="font-size: 0.7em; font-variant: small-caps; font-weight: normal;"><?php echo $_SESSION["name"]; ?></span>
<div class="line_bottom" style="display:none;">
</div>
</div>
<?php
	}
?>
</a>
<div class="header_right" id="test"> 
Test
</div>
<a href="index.php" style="text-decoration:none">
<div class="header_right" >
<div class="homeb">
<img src="images/home_button.png" width="100%" height="100%"></div>
</div>

</a>
</div>


<div class="faltu-3">

<hr style="width:90%;border:1px solid black;">
<div class="search_results">
<center>
<table cellpadding="5" cellspacing="0">
<tr>
<th>#</th>
<th>Name</th>
<th>Address</th>
</tr>
<?php
	$x=$_GET["x"]; //location, name, pincode
	$y=$_GET["y"]; //string to be searched
	$z=$_GET["z"]; //1,2,3,4
	$count=0;
	if ($x=="name")
	{ //echo "x is name";
	  $query = "select institutes.name, info.address from institutes, links, info where institutes.Id=links.IdInst AND info.idinst=institutes.id AND links.IdBuild=$z AND institutes.name LIKE '%$y%'";
	  $data = mysql_query($query);
	  $num = mysql_num_rows($data);
	  if ($num>0)
	  { while ($qrow = mysql_fetch_array($data))
	    { $count++;
?>

<tr class="sear">
<td><?php echo $count; ?></td>
<td><?php echo $qrow["name"]; ?></td>
<td><?php echo $qrow["address"]; ?></td>
</tr>
<?php
	    }
	  }
	  else
	  {
?>
<tr>
<td>-</td>
<td>No Record Found</td>
<td>-</td>
</tr>

<?php
	  } 
	}
    else
    {
		$q = "select institutes.name, info.address from institutes, links, info where institutes.id=links.idinst AND links.idbuild=$z AND institutes.id=info.idinst AND info.address LIKE '%$y%'";
		$d = mysql_query($q);
		$n = mysql_num_rows($d);
		if ($n>0)
		{ while ($qr = mysql_fetch_array($d))
		  { $count++;
?>

<tr><div class="sear">
<td><?php echo $count; ?></td>
<td><?php echo $qr["name"]; ?></td>
<td><?php echo $qr["address"]; ?></td>
</div>
</tr>
<?php
		  }
		}
		else
		{
?>
<tr>
<td>-</td>
<td>No Record Found</td>
<td>-</td>
</tr>
<?php   
		}
	}?>


</table>
</center>
</div>
<hr style="width:90%;border:1px solid black;">
</div>



<div class="footer">
<div class="footer_left">
<ul style="list-style-type:none"> <h2>Quick Links</h2>
<div class="quick_contents" >
<li><a style="text-decoration:none;" href="index.php">Home</a></li></div>
<div class="quick_contents">
<li><a style="text-decoration:none;" href="login.php">Login</a></li></div>
<div class="quick_contents">
<li><a style="text-decoration:none;" href="#">Proficiency Test</a></li></div>
<div class="quick_contents">
<li><a style="text-decoration:none;" href="#">Forum</a></li></div>

</ul>
</div>

<div class="footer_left">
<ul style="list-style-type:none"> <h2>Top 5</h2>
<div class="quick_contents">
<li><a style="text-decoration:none;" href="#">Playschools</a></li></div>
<div class="quick_contents">
<li><a style="text-decoration:none;" href="#">Kindergerten</a></li></div>
<div class="quick_contents">
<li><a style="text-decoration:none;" href="#">School</a></li></div>
<div class="quick_contents">
<li><a style="text-decoration:none;" href="#">College</a></li></div>

</ul>
</div>


<div class="footer_left">
<ul style="list-style-type:none"> <h2>About Us</h2>
<div class="quick_contents">
<li><a style="text-decoration:none;" href="aboutus.html">Company</a></li></div>
<div class="quick_contents">
<li><a style="text-decoration:none;" href="team.html">Team</a></li></div>
<div class="quick_contents">
<li><a style="text-decoration:none;" href="#">Privacy Policy</a></li></div>
<div class="quick_contents">
<li><a style="text-decoration:none;" href="terms_of_use.html">Terms of Use</a></li></div>

</ul>
</div>


<div class="footer_left">
<ul style="list-style-type:none"> <h2>Extra Links</h2>
<div class="quick_contents">
<li><a style="text-decoration:none;" href="#">FAQ's</a></li></div>

</ul>
</div>

<div class="footer_left">
<ul style="list-style-type:none"> <h2>Contact Us</h2>
<div class="quick_contents">
<li><h4>Address:</h4>Eduspace pvt. Ltd,Xyz lane,Sector-5</li></div>
<div class="quick_contents">
<li>Noida,U.P.,India</li></div>
<div class="quick_contents">
<li><h4>Email:</h4>Click Here</li></div>
</ul>
</div><div style="float:right;"><hr>
<center>© Copyright 2015. All Rights Reserved.</center></div>
</div>


</body>

</html>
